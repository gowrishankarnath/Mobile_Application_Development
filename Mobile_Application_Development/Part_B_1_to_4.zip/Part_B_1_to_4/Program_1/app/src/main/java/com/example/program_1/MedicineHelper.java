package com.example.program_1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MedicineHelper extends SQLiteOpenHelper {

    public static String DATABASE_NAME="MEDICINE.db";
    public static String MEDICINE_TABLE="Medicine";
    public static String MEDICINE_COLUMN1 = "name";
    public static String MEDICINE_COLUMN2 = "date";
    public static String MEDICINE_COLUMN3 = "time";


    public MedicineHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Medicine (name TEXT, date TEXT, time TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
